/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author mbeck
 */
public class TestHarness {
    static private final String foodNames[] = {"French fries"};

    // A few helper objects
    static private Cafe cafe = new Cafe();
    static private Scanner sc = new Scanner(System.in);   // Needed for interactive input
    static private Random rndvalue = new Random();   // Needed to generate random numbers
    static private LList transactionHistory = new LList();
    

    public static void main(String[] args) {

 
        while (true) {
            System.out.print("\nType 'v' to view menu, type 'o' to order, type 't' to view transactions, type 'q' to quit\n");
            String temp = sc.next();
            if (temp.equalsIgnoreCase("q")) {
                System.exit(0);
            } else if (temp.equalsIgnoreCase("t")) {
                //mehod call
            } else if (temp.equalsIgnoreCase("v")) {
                printMenu();
            } else if (temp.equalsIgnoreCase("o")) {
                order();
            } else {
                System.out.println("ERROR: Unknown command");
            }
        }
        
        
  
    }

    static int random(int n) {
        return Math.abs(rndvalue.nextInt()) % n;
    }

    private static String pickName(int i, String arr[]) {
        return arr[i % arr.length];
    }
    
    private static void order(){
        System.out.print("How many things do you want to order?");
        String order = sc.next();
        int orderNum=Integer.parseInt(order); 
        String item; 
        for(int i =0; i < orderNum; i++){
            System.out.println("Enter the ID of the " + i+1 + " item you want to order: "); 
            item = sc.next(); 
            String sale = "yay";
            transactionHistory.append(sale);
        }
        
    }
    
    private static void printMenu(){
        for (int i = 1; i <= 10; i++) {
            String price = String.valueOf(random(5)) + "." + String.valueOf(random(100));
            FoodItem food = cafe.newFoodItem(new BigDecimal(price), pickName(i, foodNames));
        }
        System.out.println("FoodItems:");
        System.out.println(cafe.getFoodItems());
        System.out.println();
    }

    

    

}