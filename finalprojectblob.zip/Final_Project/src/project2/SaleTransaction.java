/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;
import java.time.LocalDateTime;

/**
 *
 * @author myriambayen
 */
public class SaleTransaction {
    private Student student;
    private FoodItem foodItem;
    private LocalDateTime date;
    
    public Student getStudent(){return student;}
    public void setStudent(Student val){
        student = val;
    }
    
    public FoodItem getfoodItem(){return foodItem;}
    public void setfoodItem(FoodItem val){
        foodItem = val;
    }
    
    public void setDate(LocalDateTime date) {
        this.date = date;
    }
    public LocalDateTime getDate() {
        return date;
    }
    
    public SaleTransaction(Student stud, FoodItem food){
        setStudent (stud);
        setfoodItem (food);
        setDate(LocalDateTime.now());
    }

    public String toString(){
        return "Date and Time: " + getDate() + "       Name: " + getStudent()+ "      Food item description: " + getfoodItem();
    }

}
