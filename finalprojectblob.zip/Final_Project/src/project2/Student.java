/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;
import java.math.BigDecimal;


/**
 *
 * @author myriambayen
 */
public class Student {
    private int studentID;
    private String nameFirst;
    private String nameLast;
    private String homeAddrLine1;
    private String homeAddrLine2;
    private String homeAddrCity;
    private String homeAddrState;
    private String homeAddrZIP;
    private int currentGrade;
    private String advisor;
    private BigDecimal AccountBalance;
    private LList<SaleTransaction> saleTransactionList;

    
    public int getStudentID(){return studentID;}
    public void setStudentID(int val){
        studentID = val;
    }
    
    
    public String getnameFirst(){return nameFirst;}
    public void setnameFirst(String val){
        nameFirst = val;
    }
    
    
    public String getnameLast(){return nameLast;}
    public void setnameLast(String val){
        nameLast = val;
    }
    
    
    public String gethomeAddrLine1(){return homeAddrLine1;}
    public void sethomeAddrLine1(String val){
        homeAddrLine1 = val;
    }
    
    public String gethomeAddrLine2(){return homeAddrLine2;}
    public void sethomeAddrLine2(String val){
        homeAddrLine2 = val;
    }
    
    public String gethomeAddrCity(){return homeAddrCity;}
    public void sethomeAddrCity(String val){
        homeAddrCity = val;
    }
    
    
    public String gethomeAddrState(){return homeAddrState;}
    public void sethomeAddrState(String val){
        homeAddrState = val;
    }
    
    
    public String gethomeAddrZIP(){return homeAddrZIP;}
    public void sethomeAddrZIP(String val){
        homeAddrZIP = val;
    }
    
    
    public int getcurrentGrade(){return currentGrade;}
    public void setcurrentGrade(int val){
        currentGrade = val;
    }
    
    
    public BigDecimal getAccountBalance(){return AccountBalance;}
    public void setAccountBalance(BigDecimal val){
        AccountBalance = val;
    }
    
    public LList<SaleTransaction> getSaleTransactions(){
        return saleTransactionList;
    }
    public void addSaleTransaction(SaleTransaction sale){
        saleTransactionList.append(sale);
    }



    
    
    
    public Student(int id, String firstname, String lastname){
        setStudentID(id);
        setnameFirst(firstname);
        setnameLast(lastname);
        saleTransactionList = new LList<SaleTransaction>();
    }
    
    public String toString(){
        return "Id: " + getStudentID() + "      Name: " + getnameFirst() + getnameLast() + "      Account Balance: " + getAccountBalance();
    }

    
    public BigDecimal subAccountBalance(BigDecimal val){
        AccountBalance = AccountBalance.subtract(val);
        System.out.println("Transaction complete!");
        return AccountBalance;
    }
    
    boolean checkSufficientBalance(BigDecimal val){
        if (getAccountBalance().compareTo(val) >= 0){
            return true;
        }
        else{
            return false;
        }
    }
}
