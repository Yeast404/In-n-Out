/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import static project2.TestHarness.random;

/**
 *
 * @author myriambayen
 */
public class Cafe {
    private BST<Integer, Student> students;
    private BST<Integer, FoodItem> foodItems;
    private BST<LocalDateTime, SaleTransaction> salesByDate;
    
 

    public void setStudents(BST<Integer, Student> students) {
        this.students = students;
    }

    public void setFoodItems(BST<Integer, FoodItem> foodItems) {
        this.foodItems = foodItems;
    }

    public void setSalesByDate(BST<LocalDateTime, SaleTransaction> salesByDate) {
        this.salesByDate = salesByDate;
    }
    
    
    public BST<Integer, Student> getStudents() {
        return students;
    }

    public BST<Integer, FoodItem> getFoodItems() {
        return foodItems;
    }

    public BST<LocalDateTime, SaleTransaction> getSalesByDate() {
        return salesByDate;
    }

    
    
    public Cafe(){
        students = new BST();
        foodItems = new BST();
        salesByDate = new BST();
    }
    
    
    public Student newStudent(String first, String last){
        int id = random(100); 
        if (students.find(id) != null){
            return newStudent(first, last);
        }
        Student stud = new Student(id, first, last);
        students.insert(id, stud);
        return stud;
    }
    
    public FoodItem newFoodItem(BigDecimal cost, String d){
        int id = random(100);
        if (foodItems.find(id) != null){
            return newFoodItem(cost, d);
        }
        FoodItem food = new FoodItem(id, cost, d);
        foodItems.insert(id, food);
        return food;
    }
    
    public void makeFoodSale(Student stud, FoodItem food){
        if (stud.checkSufficientBalance(food.getPrice()) == false){
            System.out.println("ERROR YOU DON'T HAVE ENOUGH MONEY, GET BETTER");
        }
        else{
            stud.subAccountBalance(food.getPrice());
            //creates a new SaleTransaction object, and inserts it into the Cafe salesByDate BST and Student saleTransactions list
            SaleTransaction transactionObject = new SaleTransaction(stud, food);
            salesByDate.insert(transactionObject.getDate(), transactionObject);
            stud.addSaleTransaction(transactionObject);
        }
    }
    
    public void reportSalesByStudent(Student stud) {
        for(stud.getSaleTransactions().moveToStart(); stud.getSaleTransactions().currPos() < stud.getSaleTransactions().length(); stud.getSaleTransactions().next()){
            System.out.println(stud.getSaleTransactions().getValue() + "\n");
        }
    }
    
      
    
    
    public void reportSalesByStudentDate(Student stud, LocalDateTime start, LocalDateTime end){
        BSTNode<LocalDateTime, SaleTransaction> rt = salesByDate.root();
        printSalesByDateWithStudent(rt, start, end, stud);
    }
    
     public void printSalesByDateWithStudent(BSTNode<LocalDateTime, SaleTransaction>  rt, LocalDateTime start, LocalDateTime end, Student stud){
       if (rt == null) {
            return;
       }
       if (rt.key().compareTo(start) < 0){
           printSalesByDateWithStudent(rt.right(), start, end, stud);
       }
       else if (rt.key().compareTo(start) > 0 && rt.key().compareTo(end) < 0){
           if (rt.element().getStudent().getStudentID() == stud.getStudentID()){
               System.out.print(rt.element() + " \n ");
           }
           printSalesByDateWithStudent(rt.left(), start, end, stud);
           printSalesByDateWithStudent(rt.right(), start, end, stud);
       }
       else if (rt.key().compareTo(end) > 0){
           printSalesByDateWithStudent(rt.left(), start, end, stud);
       } 
    }
    
     
     
    public void reportSalesByDate(LocalDateTime start, LocalDateTime end){
       BSTNode<LocalDateTime, SaleTransaction> rt= salesByDate.root();
       printSalesByDate(rt, start, end);
       
    }
    
    
    public void printSalesByDate(BSTNode<LocalDateTime, SaleTransaction>  rt, LocalDateTime start, LocalDateTime end){
       if (rt == null) {
            return;
       }
       if (rt.key().compareTo(start) < 0){
           printSalesByDate(rt.right(), start, end);
       }
       else if (rt.key().compareTo(start) > 0 && rt.key().compareTo(end) < 0){
           printSalesByDate(rt.left(), start, end);
           System.out.print(rt.element() + " \n ");
           printSalesByDate(rt.right(), start, end);
       }
       else if (rt.key().compareTo(end) > 0){
           printSalesByDate(rt.left(), start, end);
       } 
    }
    
}
