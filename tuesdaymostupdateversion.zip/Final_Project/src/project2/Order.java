/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;

/**
 *
 * @author myriambayen
 */
public class Order {
    private int id;
    private int age;
    private boolean isAdult;


        //Constructor always starts with public and has the same name as class
        //This is signature: public Person(String nm, int ag, boolean ad)
        /*public Person(String nm, int ag, boolean ad){
              //Formal parameters:
                name = nm;
                age = ag;
                isAdult = ad;
        }*/
}
