/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;
import java.math.BigDecimal;

/**
 *
 * @author myriambayen
 */
public class MenuItem {
    int foodItemID;
    String description;
    BigDecimal price;
    BigDecimal cost;
    
    public int getfoodItemID(){return foodItemID;}
    public void setfoodItemID(int val){
        foodItemID = val;
    }
    
    
    public String getdescription(){return description;}
    public void setdescription(String val){
        description = val;
    }
    
    
    public BigDecimal getPrice(){return price;}
    public void setPrice(BigDecimal val){
        price = val;
    }
    
    public BigDecimal getCost(){return price;}
    public void setCost(BigDecimal val){
        cost = val;
    }
    
    public MenuItem(int id, BigDecimal cost, String desc){
        setfoodItemID(id);
        setPrice(cost);
        BigDecimal tmp = new BigDecimal(2.00);
        setCost(cost.divide(tmp));
        setdescription(desc);
    }
    
    
    public String toString(){
        return "Description: " + getdescription() + "        Price: $" + getPrice();
    }

}
