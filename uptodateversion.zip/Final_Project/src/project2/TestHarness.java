/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author mbeck
 */
public class TestHarness {
    static private final String foodNames[] = {"French Fries", "Animal Style Fries", "Cheeseburger", "Bacon Cheeseburger", "Double Cheeseburger", "Double Bacon Cheeseburger", "Hamburger", "Grilled Cheese", "Chocolate Milkshake", "Vanilla Milkshake", "Strawberry Milkshake", "Diet Coke", "Coke", "Sprite", "Water", "Lemonade"};
    static private final double foodPrices[] = {2.15, 4.15, 3.50, 4.00, 4.90, 5.40, 3.15, 3.25, 2.80, 2.80, 2.80, 2.30, 2.30, 2.30, 2.30, 2.30};

    
    
    // A few helper objects
    static private CentralHub controlCenter = new CentralHub();
    static private Scanner sc = new Scanner(System.in);   // Needed for interactive input
    static private LList transactionHistory = new LList();
    static private LList receiptList = new LList();
    
    

    public static void main(String[] args) {
        controlCenter.setUpArray(foodNames.length);
 
        while (true) {
            System.out.print("\nType 'm' to view menu, type 'b' to view bst, type 'o' to order, type 't' to view transactions, type 'q' to quit\n");
            String temp = sc.next();
            if (temp.equalsIgnoreCase("q")) {
                System.exit(0);
            } else if (temp.equalsIgnoreCase("t")) {
                viewTransactions();
            } else if (temp.equalsIgnoreCase("m")) {
                System.out.println();
                printMenuPretty();
            }else if (temp.equalsIgnoreCase("b")) {
                printMenuBST();
            } else if (temp.equalsIgnoreCase("o")) {
                order();
            } else {
                System.out.println("ERROR: Unknown command");
            }
        }
        
        
  
    }


    private static String pickName(int i, String arr[]) {
        return arr[i % arr.length];
    }
    
    private static void order(){
        boolean done = false; 
        String item; 
        BigDecimal total = BigDecimal.ZERO; // Initialize total to zero

        while(done == false) {
            System.out.println("Enter the ID of the item you want to order (Press 'q' When Done Ordering) : ");
            item = sc.next();
            if (item.equalsIgnoreCase("q")) {
                done = true; 
            } 
            else{
            int itemId = Integer.parseInt(item);
            MenuItem ordered = controlCenter.getFoodItembyID(itemId);
            BigDecimal price = ordered.getPrice();
            total = total.add(price); // Update total by adding the price
            //ystem.out.println(ordered + " added to your cart.");
            transactionHistory.append(ordered);
            receiptList.append(ordered);
            }
            
        }
        System.out.println("_________________________");
        System.out.println("\n RECEIPT \n");
        System.out.println(receiptList);
        
        BigDecimal taxPercent = new BigDecimal(2.00);
        BigDecimal taxPercentMultiplier = new BigDecimal(0.02);
        System.out.println("Tax percentage " + taxPercent + "%");
        BigDecimal taxValue = taxPercentMultiplier.multiply(total);
        System.out.println("Tax value:      $" + taxValue.round(new MathContext(2)));
        BigDecimal finalCost = taxValue.add(total);
        System.out.println("TOTAL: $" + finalCost.round(new MathContext(3)));
        System.out.println("_________________________");

        
        receiptList.clear();
    }
    
    private static void printMenuBST(){
        for (int i = 0; i < foodNames.length; i++) {
            BigDecimal price = new BigDecimal(foodPrices[i]);
            MenuItem food = controlCenter.newFoodItem(price, pickName(i, foodNames), i);
        }
        System.out.println("FoodItems:");
        System.out.println(controlCenter.getFoodItems());
        System.out.println();
    }
    
    private static void printMenuPretty(){
        for (int i = 0; i < foodNames.length; i++) {
            BigDecimal price = new BigDecimal(foodPrices[i]);
            MenuItem food = controlCenter.newFoodItem(price, pickName(i, foodNames), i);
        }
        System.out.println("FoodItems:");
        controlCenter.printFoodItems();
    }
    
    private static void viewTransactions(){
        System.out.println("Everything that has been ordered today:");
        System.out.println(transactionHistory);
    }

    
    


    

}