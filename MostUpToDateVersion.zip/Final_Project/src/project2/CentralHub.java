/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;
import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDateTime;
import java.util.Random;

/**
 *
 * @author myriambayen
 */
public class CentralHub {
    private BST<Integer, MenuItem> foodItems;
    int IDList[];
    
 



    public void setFoodItems(BST<Integer, MenuItem> foodItems) {
        this.foodItems = foodItems;
    }
    
    public MenuItem getFoodItembyID(int id) {
        return (foodItems.find(id));
    }
    
    public void setUpArray(int len){
        IDList = new int[len];
    }


    
    


    public BST<Integer, MenuItem> getFoodItems() {
        return foodItems;
    }
    
    public void printFoodItems() {
        for (int i = 0; i < foodItems.size(); i++){
            MenuItem curr = foodItems.find(IDList[i]);
            System.out.println(curr.getdescription() + "        Price: $" + curr.getPrice() + "           ID: " + curr.getfoodItemID());
        }
    }

    
    public BST<Integer, MenuItem> printPrettyFoodItems() {
        return foodItems;
    }


    
    
    public CentralHub(){
        foodItems = new BST();
    }
    
    

    

    public MenuItem newFoodItem(BigDecimal cost, String d, int spot){
        Random r = new Random();
        int id = r.nextInt(100);
        if (foodItems.find(id) != null){
            return newFoodItem(cost.round(new MathContext(3)), d, spot);
        }
        MenuItem food = new MenuItem(id, cost.round(new MathContext(3)), d);
        foodItems.insert(id, food);
        IDList[spot] = id;
        return food;
    }
    


    
}
